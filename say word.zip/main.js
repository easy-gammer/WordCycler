let inpTxt = document.querySelector('#inpTxt');
let inpNum = document.querySelector('#inpNum');
let copTxt = document.querySelector('#copTxt');
let sent = document.querySelector('#button');
let copyBtn = document.querySelector('#copy');
let selection = document.querySelector('.selection');

let defSel = 'True'

sent.addEventListener('click', () => {
  if (inpTxt.value !== '' && inpNum.value !== '') {
    let valTxt = inpTxt.value;
    let valNum = parseInt(inpNum.value);
    let select = selection.value;// Ensure it's an integer
    
    let result = '';
    for (let i = 0; i < valNum; i++) {
      if (select === 'True') { // Correctly access selection value
        result += i + 1 + '.' + valTxt + '\n';
        delete 'False';
      } else {
        result += valTxt + '\n';
        delete 'True';
      }
    }
    copTxt.innerText = result; // Move this outside of the loop
  } else {
    alert('Please fill up the blanks correctly');
  }
});

copyBtn.addEventListener('click', () => {
  let textToCopy = copTxt.innerText;

  if (textToCopy.trim() !== '') {
    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        alert('Text copied to clipboard!');
      })
      .catch(err => {
        alert('Failed to copy: ' + err);
      });
  } else {
    alert('Nothing to copy!');
  }
});